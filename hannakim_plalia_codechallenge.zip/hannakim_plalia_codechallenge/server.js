var express = require("express");
var app = express();

var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({extended: true}));


app.use(express.static(__dirname + "/static"));

app.set("views", __dirname + "/views");
app.set("view engine", "ejs");


app.get('/', function (req, res){
	req.
	res.render('index', {title: "Hanna Kim - Plalia Coding Challenge"});
})


app.get('/*', function (req, res){
	res.send("<h1>Not Found</h1>");
})


app.post('/hello', function (req, res){
	console.log("this is what's input", req.body);
	if (req.body.prompt === 'hello'){
		res.send("<h1>Universe</h1>");
	} else {
		res.send("<h1>Not Found</h1>");
	};
})


app.listen(8000, function(){
	console.log("Listening on port 8000");
})